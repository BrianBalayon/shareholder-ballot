export const VALUE = "value";
