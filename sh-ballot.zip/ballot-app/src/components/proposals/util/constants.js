export const PROPOSAL_INFO = [
  {
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
  },
  {
    description:
      "Sed malesuada arcu velit, sit amet luctus augue lacinia nec. Nullam volutpat turpis et lacus tincidunt, eget interdum eros pharetra. Etiam ultricies dolor in finibus aliquet. Morbi euismod tellus in enim tincidunt venenatis in eget arcu. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec ante nisi, feugiat vitae lectus eu, fermentum pellentesque ante. Maecenas feugiat justo at est semper mattis. Sed fringilla ipsum turpis, ac luctus magna ullamcorper eu. Suspendisse quis ante odio. Proin leo enim, aliquam et hendrerit non, pharetra non sem. Etiam dictum purus a felis vehicula rhoncus. Mauris id magna placerat, gravida mauris vitae, scelerisque ipsum. Vivamus ultricies velit at pretium condimentum. Sed vitae dolor ut tellus malesuada facilisis a quis augue."
  },
  {
    description:
      "Nunc nec justo sed tortor pellentesque eleifend. Proin vestibulum nisi sed congue imperdiet. Aliquam vitae pharetra tortor. Integer porttitor tellus orci, eu commodo arcu gravida quis. Integer vel mauris vitae libero commodo hendrerit porta ut erat. Quisque neque quam, tincidunt id est at, vehicula tristique mi. Proin eu vulputate diam. Ut dolor turpis, pellentesque et tellus ac, dictum rutrum arcu."
  },
  {
    description:
      "Mauris eu commodo libero, sit amet vestibulum diam. Suspendisse ac pharetra est, eget iaculis mauris. Fusce justo metus, tempor eget diam in, pulvinar congue velit. Pellentesque quis commodo dui. Nullam vel enim nisi. Sed tempus gravida augue, et sagittis metus cursus ut. Suspendisse ut leo id urna porttitor euismod eget ac sem. Suspendisse auctor interdum lacus nec iaculis. Donec suscipit augue non egestas pretium. Quisque eu tellus vitae nisi molestie dignissim. In non risus libero. Sed rutrum odio ac nunc tempus ullamcorper sed eget turpis."
  }
];
