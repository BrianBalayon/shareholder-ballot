export const VOTING_MODE_INDEX_TO_STRING_ARRAY = [
  "One Vote Per Share",
  "One Vote Only",
  "Not Set"
];
